#!/bin/bash

# If no theme is provided, try to detect the active one
if [ -z "$1" ]; then
    ACTIVE_THEME=""
    if [ -f "$HOME/.config/jwm/theme" ]; then
        for theme_path in "$HOME/.config/jwm/themes/"*; do
            if cmp -s "$HOME/.config/jwm/theme" "$theme_path"; then
                ACTIVE_THEME=$(basename "$theme_path")
                break
            fi
        done
    fi
else
    ACTIVE_THEME="$1"
    # Apply the selected theme
    cp -a "$HOME/.config/jwm/themes/$ACTIVE_THEME" "$HOME/.config/jwm/theme"
fi

# Update the themes-list file
THEME_LIST_FILE="$HOME/.config/jwm/themes-list"

cat << 'EOF' > "$THEME_LIST_FILE"
<?xml version="1.0" encoding="UTF-8"?>
<JWM>
    <Menu icon="preferences-desktop-theme" label="Themes">
EOF

for theme_path in "$HOME/.config/jwm/themes/"*; do
    [ -e "$theme_path" ] || continue
    theme=$(basename "$theme_path")
    label="${theme//-/ }"
    
    if [ "$theme" = "$ACTIVE_THEME" ]; then
        # Use an indicator like [ Active ] or an asterisk
        label="✓ $label"
    fi
    
    echo "        <Program label=\"$label\" confirm=\"false\">\$HOME/.config/jwm/set-theme.sh \"$theme\"</Program>" >> "$THEME_LIST_FILE"
done

cat << 'EOF' >> "$THEME_LIST_FILE"
    </Menu>
</JWM>
EOF

# Restart JWM only if a theme was passed as an argument (meaning we just changed it)
if [ -n "$1" ]; then
    jwm -restart
fi
