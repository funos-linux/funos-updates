#!/bin/sh

# Automatically apply monitor settings configured via lxrandr
if [ -f "$HOME/.config/autostart/lxrandr-autostart.desktop" ]; then
    grep '^Exec=' "$HOME/.config/autostart/lxrandr-autostart.desktop" | tail -n 1 | cut -d= -f2- | sh
fi

# Sync JWM menu on every login to ensure it matches offline changes
mjwm --no-backup --silent
